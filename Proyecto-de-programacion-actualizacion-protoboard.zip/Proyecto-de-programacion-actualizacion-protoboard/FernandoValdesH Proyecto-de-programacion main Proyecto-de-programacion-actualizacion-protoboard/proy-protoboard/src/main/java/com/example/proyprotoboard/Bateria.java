package com.example.proyprotoboard;

public class Bateria{
    double voltaje = 2.4;
    int conectorPositivox = -2;
    int conectorPositivoy = -2;
    int conectorNegativox = -3;
    int conectorNegativoy = -3;
    Boolean explotada = false;
}