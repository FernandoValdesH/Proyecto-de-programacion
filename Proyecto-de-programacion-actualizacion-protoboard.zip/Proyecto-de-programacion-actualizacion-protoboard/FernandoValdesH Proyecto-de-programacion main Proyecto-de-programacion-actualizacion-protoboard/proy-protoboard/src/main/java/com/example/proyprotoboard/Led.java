package com.example.proyprotoboard;
public class Led extends Indicador{
    Boolean encendido;
    Boolean revisado;
    public Led(){
        super();
        this.encendido=false;
        this.revisado=false;
    }

}
