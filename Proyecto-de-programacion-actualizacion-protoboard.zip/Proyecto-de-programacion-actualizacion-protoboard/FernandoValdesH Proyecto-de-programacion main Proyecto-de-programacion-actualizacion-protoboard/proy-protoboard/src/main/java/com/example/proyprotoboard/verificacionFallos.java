package com.example.proyprotoboard;
public class verificacionFallos {
    
}
//Posiblemente se elimine, revisar luego